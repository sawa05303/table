window.onload = (event) => {
    const spoofNavBtn = document.querySelector("#spoofNav");
    const spoofUABtn = document.querySelector("#spoofUA");
    const spoofCanvasBtn = document.querySelector("#spoofCanvas");
    const blockImageBtn = document.querySelector("#blockImg");
    const blockJSBtn = document.querySelector("#blockJS");
    const spinner = document.querySelector("#spinner");
    chrome.storage.sync.get("NAV_SPOOFED", ({ NAV_SPOOFED }) => {
        if (NAV_SPOOFED) {
            spoofNavBtn.textContent = "Navigator Spoofed";
            spoofNavBtn.classList.add("btn-danger");
            spoofNavBtn.classList.remove("btn-primary");
        } else {
            spoofNavBtn.textContent = "Spoof Navigator";
            spoofNavBtn.classList.add("btn-primary");
            spoofNavBtn.classList.remove("btn-danger");
        }
    });
    chrome.storage.sync.get("CANVAS_SPOOFED", ({ CANVAS_SPOOFED }) => {
        if (CANVAS_SPOOFED) {
            spoofCanvasBtn.textContent = "Canvas Spoofed";
            spoofCanvasBtn.classList.add("btn-danger");
            spoofCanvasBtn.classList.remove("btn-primary");
        } else {
            spoofCanvasBtn.textContent = "Spoof Canvas";
            spoofCanvasBtn.classList.add("btn-primary");
            spoofCanvasBtn.classList.remove("btn-danger");
        }
    });
    chrome.storage.sync.get("UA_SPOOFED", ({ UA_SPOOFED }) => {
        if (UA_SPOOFED) {
            spoofUABtn.textContent = "User Agent Spoofed";
            spoofUABtn.classList.add("btn-danger");
            spoofUABtn.classList.remove("btn-primary");
        } else {
            spoofUABtn.textContent = "Spoof User Agent";
            spoofUABtn.classList.add("btn-primary");
            spoofUABtn.classList.remove("btn-danger");
        }
    });
    chrome.storage.sync.get("IMG_BLOCKED", ({ IMG_BLOCKED }) => {
        if (IMG_BLOCKED) {
            blockImageBtn.textContent = "Images Blocked";
            blockImageBtn.classList.add("btn-danger");
            blockImageBtn.classList.remove("btn-primary");
        } else {
            blockImageBtn.textContent = "Block Images";
            blockImageBtn.classList.add("btn-primary");
            blockImageBtn.classList.remove("btn-danger");
        }
    });
    chrome.storage.sync.get("JS_BLOCKED", ({ JS_BLOCKED }) => {
        if (JS_BLOCKED) {
            blockJSBtn.textContent = "JS Blocked";
            blockJSBtn.classList.add("btn-danger");
            blockJSBtn.classList.remove("btn-primary");
        } else {
            blockJSBtn.textContent = "Block JS";
            blockJSBtn.classList.add("btn-primary");
            blockJSBtn.classList.remove("btn-danger");
        }
    });
    spoofNavBtn.addEventListener("click", (event) => {
        spinner.classList.remove("d-none");
        chrome.storage.sync.get("NAV_SPOOFED", ({ NAV_SPOOFED }) => {
            const navSpoofed = !NAV_SPOOFED;
            chrome.storage.sync.set({ NAV_SPOOFED: navSpoofed }, () => {
                spoofNavBtn.textContent = navSpoofed ? "Navigator Spoofed" : "Spoof Navigator";
                switchBtnState(spoofNavBtn);
                spinner.classList.add("d-none");
                spoofNavigator(navSpoofed);
            });
        });
    });
    spoofCanvasBtn.addEventListener("click", (event) => {
        spinner.classList.remove("d-none");
        chrome.storage.sync.get("CANVAS_SPOOFED", ({ CANVAS_SPOOFED }) => {
            const canvasSpoofed = !CANVAS_SPOOFED;
            chrome.storage.sync.set({ CANVAS_SPOOFED: canvasSpoofed }, async () => {
                spoofCanvasBtn.textContent = canvasSpoofed ? "Canvas Spoofed" : "Spoof Canvas";
                switchBtnState(spoofCanvasBtn);
                spinner.classList.add("d-none");
                spoofCanvas(canvasSpoofed);
            });
        });
    });
    spoofUABtn.addEventListener("click", (event) => {
        spinner.classList.remove("d-none");
        chrome.storage.sync.get("UA_SPOOFED", ({ UA_SPOOFED }) => {
            const uaSpoofed = !UA_SPOOFED;
            chrome.storage.sync.set({ UA_SPOOFED: uaSpoofed }, async () => {
                let userAgent = uaSpoofed 
                    ? "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36" 
                    : window.navigator.userAgent;
                spoofUABtn.textContent = uaSpoofed ? "User Agent Spoofed" : "Spoof User Agent";
                chrome.declarativeNetRequest.updateDynamicRules(
                    {
                        removeRuleIds: [1],
                        addRules: [
                            {
                                id: 1,
                                priority: 10,
                                action: {
                                    type: "modifyHeaders",
                                    requestHeaders: [
                                        {
                                            header: "user-agent",
                                            operation: "set",
                                            value: userAgent,
                                        },
                                    ],
                                },
                                condition: {
                                    urlFilter: "*",
                                    resourceTypes: [
                                        "main_frame", "sub_frame", "stylesheet", "script", 
                                        "image", "font", "xmlhttprequest", "ping", 
                                        "csp_report", "media", "websocket", "other"
                                    ],
                                },
                            },
                        ],
                    },
                    () => {
                        switchBtnState(spoofUABtn);
                        spinner.classList.add("d-none");
                        reload();
                    }
                );
            });
        });
    });
    blockImageBtn.addEventListener("click", (event) => {
        spinner.classList.remove("d-none");
        chrome.storage.sync.get("IMG_BLOCKED", ({ IMG_BLOCKED }) => {
            const imageBlocked = !IMG_BLOCKED;
            chrome.storage.sync.set({ IMG_BLOCKED: imageBlocked }, () => {
                blockImageBtn.textContent = imageBlocked ? "Images Blocked" : "Block Images";
                chrome.contentSettings["images"].set(
                    {
                        primaryPattern: "<all_urls>",
                        setting: imageBlocked ? "block" : "allow",
                    },
                    () => {
                        switchBtnState(blockImageBtn);
                        spinner.classList.add("d-none");
                        reload();
                    }
                );
            });
        });
    });
    blockJSBtn.addEventListener("click", (event) => {
        spinner.classList.remove("d-none");
        chrome.storage.sync.get("JS_BLOCKED", ({ JS_BLOCKED }) => {
            const jsBlocked = !JS_BLOCKED;
            chrome.storage.sync.set({ JS_BLOCKED: jsBlocked }, () => {
                blockJSBtn.textContent = jsBlocked ? "JS Blocked" : "Block JS";
                chrome.contentSettings["javascript"].set(
                    {
                        primaryPattern: "<all_urls>",
                        setting: jsBlocked ? "block" : "allow",
                    },
                    () => {
                        switchBtnState(blockJSBtn);
                        spinner.classList.add("d-none");
                        reload();
                    }
                );
            });
        });
    });
    async function getCurrentTabId() {
        let [tab] = await chrome.tabs.query({
            active: true,
            currentWindow: true,
        });
        return tab.id;
    }

    async function reload() {
        const tabId = await getCurrentTabId();
        chrome.tabs.reload(tabId, { bypassCache: true });
    }
    function switchBtnState(btn) {
        btn.classList.toggle("btn-primary");
        btn.classList.toggle("btn-danger");
    }
    function spoofNavigator(navSpoofed) {
        const id = "inject_script_navigator";
        if (navSpoofed) {
            chrome.scripting.registerContentScripts(
                [
                    {
                        id,
                        matches: ["<all_urls>"],
                        allFrames: true,
                        runAt: "document_start",
                        js: ["js/navigatorContentScript.js"],
                    },
                ],
                () => {
                    reload();
                }
            );
        } else {
            chrome.scripting.unregisterContentScripts({ ids: [id] }, () => {
                reload();
            });
        }
    }
    async function spoofCanvas(canvasSpoofed) {
        const id = "inject_script_canvas";
        if (canvasSpoofed) {
            chrome.scripting.registerContentScripts(
                [
                    {
                        id,
                        matches: ["<all_urls>"],
                        allFrames: true,
                        runAt: "document_start",
                        js: ["js/canvasContentScript.js"],
                    },
                ],
                () => {
                    reload();
                }
            );
        } else {
            chrome.scripting.unregisterContentScripts({ ids: [id] }, () => {
                reload();
            });
        }
    }
    async function initSettings() {
        const settingsToggles = document.getElementsByClassName("settings_toggle");
        const settingsTexts = document.getElementsByClassName("settings_text");
        
        chrome.storage.local.get(null, async (n) => {
            for (const e of settingsToggles) {
                e.classList.remove("on", "off");
                e.classList.add(n[e.dataset.settings] ? "on" : "off");
                e.addEventListener("click", () => t(e));
            }
            for (const s of settingsTexts) {
                s.value = n[s.dataset.settings] !== undefined ? n[s.dataset.settings] : "";
                s.addEventListener("input", () => t(s));
            }
        });
    }
    async function t(element) {
        const state = element.classList.contains("settings_toggle") ? !element.classList.contains("off") : parseInt(element.value);
        await chrome.storage.local.set({ [element.dataset.settings]: state });
        
        if (element.classList.contains("settings_toggle")) {
            element.classList.remove("on", "off");
            element.classList.add(state ? "on" : "off");
        }
    }
    initSettings();
};
